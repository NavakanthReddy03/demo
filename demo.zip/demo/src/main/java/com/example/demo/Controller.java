package com.example.demo;

import java.util.Iterator;
import java.util.Set;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import redis.clients.jedis.Jedis;

@RestController
public class Controller {
	
	@Autowired
	Jedis jedis;
	
	@GetMapping("/itemsCount")
	public int getItemCount() {
		jedis.select(0);
		
	    Set<String> names=jedis.keys("*");
	    System.out.println("Available Objects in Cache");
	    Iterator<String> it = names.iterator();
	    int count=0;
	    while (it.hasNext()) {
	        String s = it.next();
	        
	        count++;
	    }
	    
	    System.out.println(count);
	    return count;
	}
	
	@GetMapping("/itemsSize")
	public long getItemSize() {
		jedis.select(0);

	    Set<String> names=jedis.keys("*");
	    System.out.println("Available Objects Size in Cache");
	    Iterator<String> it = names.iterator();
	    long count=0;
	    while (it.hasNext()) {
	        String s = it.next();
	        count+=jedis.memoryUsage(s);
	    }
	    System.out.println(count);
	    return count;
	}
	
	@GetMapping("/itemsSize/{id}")
	public long getItemSize(@PathVariable String id) {
		jedis.select(0);
	    return jedis.memoryUsage(id);
	 
	}

}
