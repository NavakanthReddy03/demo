package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import redis.clients.jedis.Jedis;

@Configuration
public class JedisConfig {
	@Bean
	public Jedis jedis() {
		Jedis jedis = new Jedis("redis://admin:Admin_123@redis-11679.c263.us-east-1-2.ec2.cloud.redislabs.com:11679");
		return jedis;
	}

}
