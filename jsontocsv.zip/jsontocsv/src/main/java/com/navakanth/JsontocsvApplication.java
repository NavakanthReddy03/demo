package com.navakanth;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.opencsv.CSVWriter;

@SpringBootApplication
public class JsontocsvApplication {

	public static void main(String[] args) {
		
	     JSONParser jsonParser = new JSONParser();
	        try (FileReader reader = new FileReader("data.json")) {
	            //Read JSON file
	            Object obj = jsonParser.parse(reader);

	            JSONArray employeeList = (JSONArray) obj;
	            List<String[]> data = new ArrayList<>();
	            //Write the CSV file
	            try (CSVWriter csvWriter = new CSVWriter(new FileWriter("data.csv"))) {
	            	// Extract the column names
	                JSONObject firstEmployee = (JSONObject) employeeList.get(0);
	             
	                Set<String> keys = firstEmployee.keySet();
	                String[] headers = keys.toArray(new String[keys.size()]);
	                data.add(headers);
	             
	                for (Object employee : employeeList) {
	                    JSONObject employeeObject = (JSONObject) employee;
	                    //Get employee first name
	                    String name = (String) employeeObject.get("name");
	                    //Get employee last name
	                    String age = String.valueOf(employeeObject.get("age"));
	                    //Get employee website name
	                    String address = (String) employeeObject.get("address");
	          
	                    String city = (String) employeeObject.get("city");
	                    String state = (String) employeeObject.get("state");
	                    String zip = (String) employeeObject.get("zip");
	                    String phone = (String) employeeObject.get("phone");
	                    String email = (String) employeeObject.get("email");
	                    data.add(new String[] {name, age, address, city, state,zip,phone,email});
	                }
	                csvWriter.writeAll(data);
	                csvWriter.close();
	                System.out.println("CSV file was created successfully !!!");
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        } catch (IOException | ParseException e) {
	            e.printStackTrace();
	        }
	}

}
